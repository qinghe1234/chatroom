package com.example.demo.utils;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class HiKariUtils {
	static DataSource dataSource;
//	static {
//		try {
//		InputStream in = HiKariUtils.class.getClassLoader().getResourceAsStream("hikari.properties");
//		Properties properties = new Properties();
//		properties.load(in);
//		
//		//实例化配置信息
//		HikariConfig config = new HikariConfig(properties);
//		//实例化连接池
//		dataSource = new HikariDataSource(config);
//		
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	static {
		try {
		 
		//实例化配置信息
		HikariConfig config = new HikariConfig();
		config.setDriverClassName("com.mysql.jdbc.Driver");
		config.setJdbcUrl("jdbc:mysql://10.10.10.190:3306/xy?characterEncoding=utf8&useSSL=false");
		config.setUsername("root");
		config.setPassword("root");
		config.setMaximumPoolSize(8);
		
		//实例化连接池
		dataSource = new HikariDataSource(config);
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		
		try {
			return dataSource.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		  
	}
	public static DataSource getDataSource() {
		return dataSource;
	}
	/**
	 * 释放资源
	 */
	public static void closeConn(ResultSet rs,Statement stmt ,Connection conn) {
		try {
			if(rs!=null) {
				rs.close();
			}
			if(stmt!=null) {
			stmt.close();
			}
			if(conn!=null) {
			conn.close();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	 
}
