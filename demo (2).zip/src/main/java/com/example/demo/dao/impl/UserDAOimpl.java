package com.example.demo.dao.impl;

import com.example.demo.dao.UserDao;
import com.example.demo.pojo.User;
import com.example.demo.utils.HiKariUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;
public class UserDAOimpl implements UserDao {
    private final QueryRunner runner = new QueryRunner(HiKariUtils.getDataSource());

    @Override
    public User getUserById(int id) throws SQLException {
        String sql = "select * from `users` where id = ?";
        User query = runner.query(sql, new BeanHandler<>(User.class));
        return query;
    }

    @Override
    public User getUserByName(String name) throws SQLException {
        String sql = "select * from `users` where name = ?";
        User query = runner.query(sql, new BeanHandler<>(User.class), name);
        return query;
    }
    @Override
    public boolean addUser(User user) throws SQLException {
        User userByName = getUserByName(user.getName());
        if (userByName == null){
            return false;
        }
        String sql = "insert into `users` values(?,?,?,?,?,?)";
        int update = runner.update(sql, null, user.getName(), user.getPasswd(), user.getAge(), user.getAddress(), user.getPhone());
        if (update > 0){
            return true;
        }else {
            return false;
        }
    }
    @Override
    public boolean deleteUser(User u) throws SQLException {
        String sql = "delete from `users` where id = ? and passwd = ?";
        if (runner.update(sql, u.getId(), u.getPasswd()) > 0){
            return true;
        }else{
            return false;
        }
    }
    @Override
    public boolean updateUser(User user) throws SQLException {
        String sql = "update `users` set name = ?, age = ?, address = ?, phone = ? where id = ?";
        if (runner.update(sql, user.getName(), user.getAge(), user.getAddress(), user.getPhone(), user.getId()) > 0){
            return true;
        }else {
            return false;
        }
    }
}
