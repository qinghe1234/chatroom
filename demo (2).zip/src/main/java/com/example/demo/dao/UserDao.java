package com.example.demo.dao;

import com.example.demo.pojo.User;

import java.sql.SQLException;

public interface UserDao {
    User getUserById(int id) throws SQLException;
    User getUserByName(String name) throws SQLException;
    boolean addUser(User user) throws SQLException;
    boolean deleteUser(User u) throws SQLException;
    boolean updateUser(User user) throws SQLException;


}
