package com.example.demo.pojo;

public class User {
    private Integer id;
    private String name;
    private String passwd;
    private Integer age;
    private String address;
    private String phone;

    public User(Integer id, String name, String passwd, Integer age, String address, String phone) {
        this.id = id;
        this.name = name;
        this.passwd = passwd;
        this.age = age;
        this.address = address;
        this.phone = phone;
    }

    public User(String name, String passwd, Integer age, String address, String phone) {
        this.id = null;
        this.phone = phone;
        this.address = address;
        this.age = age;
        this.passwd = passwd;
        this.name = name;
    }

    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", passwd='" + passwd + '\'' +
                ", age=" + age +
                ", address='" + address + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
