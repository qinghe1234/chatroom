package com.example.demo.pojo;

public class ChatRoom {
    private int id;
    private User user;
    private String content;
    private String time;
    private String type;
    private String name;

    public ChatRoom(int id, User user, String content, String time, String type, String name) {
        this.id = id;
        this.user = user;
        this.content = content;
        this.time = time;
        this.type = type;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
