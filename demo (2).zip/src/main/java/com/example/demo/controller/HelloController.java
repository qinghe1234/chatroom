package com.example.demo.controller;

import com.example.demo.pojo.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")  //定义根路径
public class HelloController {
    @GetMapping("/hello")
    public String hello() {
        User u = new User(null, "zhangsan", "123456", 18, "北京", "123456789");
        return u.toString();
    }
    @GetMapping("/login")//登录
    public String login() {
//        实例化 user
        return "";
    }
    @GetMapping("/sing")
    public String sing(
            @RequestParam String name,
            @RequestParam String passwd,
            @RequestParam(required = false) Integer age,
            @RequestParam(required = false) String address,
            @RequestParam(required = false) String phone) {
        // 参数校验
        if (name.isEmpty() || passwd.isEmpty()) {
            return "没有找到name和passwd字段";
        }
        // 实例化 User
        User user = new User(name, passwd, age, address, phone);
        System.out.println(user);
        // 返回结果
        return user.toString();
    }
    @GetMapping("/out")
    public String out() {
        return "out";
    }


}
